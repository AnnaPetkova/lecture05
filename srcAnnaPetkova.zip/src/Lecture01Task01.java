public class Lecture01Task01 {
    public static void main(String[] args) {

        double A = 13.2;
        double B = 29.5;
        double C = 22.1;

        System.out.println("22.1 between 13.2 and 29.1");
    }
}
