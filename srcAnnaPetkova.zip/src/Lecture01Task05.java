
// Homework , Task 5

public class Lecture01Task05 {
    public static void main(String[] args) {

        int i = 5;
        i--;
        // prints 4
        System.out.println(i--);
        // prints 3
        System.out.println(i);
        // prints 2
        System.out.println(--i);
        // prints 1
        System.out.println(--i);
        // prints 0
        System.out.println(--i);

        int b = 21;
        b--;
        // prints 20
        System.out.println(b--);
        // prints 19
        System.out.println(b);
        // prints 18
        System.out.println(--b);
        // prints 17
        System.out.println(--b);
        // prints 16
        System.out.println(--b);

        int c = 44;
        c--;
        // prints 43
        System.out.println(c--);
        // prints 42
        System.out.println(c);
        // prints 41
        System.out.println(--c);
        // prints 40
        System.out.println(--c);
        // prints 39
        System.out.println(--c);
    }
}