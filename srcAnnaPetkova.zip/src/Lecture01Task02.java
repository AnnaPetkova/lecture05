
public class Lecture01Task02 {
    public static void main(String[] args) {
        int a = 25;
        System.out.println(a);
        int b = 14;
        System.out.println(b);
        int sum = a + b;
        int result = a - b;
        int multiplication = a * b;
        int division = a / b;
        System.out.println(sum);
        System.out.println(result);
        System.out.println(multiplication);
        System.out.println(division);


    }
}