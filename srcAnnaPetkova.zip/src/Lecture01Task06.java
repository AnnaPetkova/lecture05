public class Lecture01Task06 {
    public static void main(String[] args) {


        int first = 1;
        int second = 2;
        int third = 3;
                System.out.println("num a" + first);
        System.out.println("num a" + second);
        System.out.println("num a" + third);






    }
}
