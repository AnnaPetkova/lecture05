import java.util.Scanner;

public class Lecture01Task07 {
    public static void main(String[] args) {






    }
}