
// Homework , Task 4

public class Lecture01Task04 {
    public static void main(String[] args) {

        int i = 1;
        i++;
        // prints 2
        System.out.println(i++);
        // prints 3
        System.out.println(i);
        // prints 4
        System.out.println(++i);
        // prints 5
        System.out.println(++i);
        // prints 6
        System.out.println(++i);

        int b = 21;
        b++;
        // prints 22
        System.out.println(b++);
        // prints 23
        System.out.println(b);
        // prints 24
        System.out.println(++b);
        // prints 25
        System.out.println(++b);
        // prints 26
        System.out.println(++b);
    }
}