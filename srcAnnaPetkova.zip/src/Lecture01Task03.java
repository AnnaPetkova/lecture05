public class Lecture01Task03 {
    public static void main(String[] args) {

      int num1 = 10;
      int num2= 20;
        System.out.println("Original values before swapping are:");
        System.out.println("Value of number 1 is " +num1);
        System.out.println("Value of number 2 is " +num2);
        System.out.println("Value after swapping are:");
        System.out.println("Value of number 2 is " +num1);
        System.out.println("Value of number 1 is " +num2);
    }

}
